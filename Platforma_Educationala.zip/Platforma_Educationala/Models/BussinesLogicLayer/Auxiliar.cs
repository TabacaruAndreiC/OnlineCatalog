﻿using Platforma_Educationala.Models.EntityLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Platforma_Educationala.Models.BussinesLogicLayer
{
    public static class Auxiliar
    {
        public static Class myClass { get; set; }
    }

    public class Corigenti
    {
        public string nume { get; set; }
        public double medie { get; set; }
        public string materie { get; set; }

    }
}
