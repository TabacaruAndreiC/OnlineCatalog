-- Crearea tabelului Users
CREATE TABLE Users (
    ID INT PRIMARY KEY,
    Username VARCHAR(50),
    Password VARCHAR(50)
);

-- Crearea tabelului Profesor
CREATE TABLE Profesor (
    ID_profesor INT PRIMARY KEY,
    Nume VARCHAR(50)
);

-- Crearea tabelului Note
CREATE TABLE Note (
    Nota_Crt INT PRIMARY KEY,
    Nota INT,
    Data DATE,
    Teza VARCHAR(50)
);

-- Crearea tabelului Materie
CREATE TABLE Materie (
    MaterieId INT PRIMARY KEY
);

-- Crearea tabelului Elev
CREATE TABLE Elev (
    ID_elev INT PRIMARY KEY,
    Nume VARCHAR(50)
);

-- Crearea tabelului Class
CREATE TABLE Class (
    ID INT PRIMARY KEY,
    Denumire VARCHAR(50),
    Diriginte INT,
    FOREIGN KEY (Diriginte) REFERENCES Profesor(ID_profesor)
);

-- Crearea tabelului Absente
CREATE TABLE Absente (
    Abs_Crt INT PRIMARY KEY,
    Tip VARCHAR(50),
    Data DATE
);

-- Legarea tabelei Users cu tabela Profesor
ALTER TABLE Users
ADD ID_profesor INT,
FOREIGN KEY (ID_profesor) REFERENCES Profesor(ID_profesor);

-- Legarea tabelei Users cu tabela Elev
ALTER TABLE Users
ADD ID_elev INT,
FOREIGN KEY (ID_elev) REFERENCES Elev(ID_elev);

-- Legarea tabelei Note cu tabela Users
ALTER TABLE Note
ADD UserID INT,
FOREIGN KEY (UserID) REFERENCES Users(ID);

-- Legarea tabelei Note cu tabela Materie
ALTER TABLE Note
ADD MaterieId INT,
FOREIGN KEY (MaterieId) REFERENCES Materie(MaterieId);

-- Legarea tabelei Note cu tabela Elev
ALTER TABLE Note
ADD ID_elev INT,
FOREIGN KEY (ID_elev) REFERENCES Elev(ID_elev);

-- Legarea tabelei Elev cu tabela Class
ALTER TABLE Elev
ADD ClassID INT,
FOREIGN KEY (ClassID) REFERENCES Class(ID);

-- Legarea tabelei Absente cu tabela Elev
ALTER TABLE Absente
ADD ID_elev INT,
FOREIGN KEY (ID_elev) REFERENCES Elev(ID_elev);

-- Ad�ugarea coloanei "Denumire" la tabela "Materie"
ALTER TABLE Materie
ADD Denumire VARCHAR(50);

-- Crearea procedurii stocate GetAbs
CREATE PROCEDURE GetAbs
    @ID INT,
    @Denumire VARCHAR(50)
AS
BEGIN
    SELECT Abs_Crt, Tip, Data
    FROM Absente a
    INNER JOIN Elev e ON e.ID_elev = a.ID_elev
    INNER JOIN Materie m ON m.MaterieId = a.MaterieId
    WHERE e.ID_elev = @ID AND m.Denumire = @Denumire
END;
GO

-- Restul codului t�u
-- ...

